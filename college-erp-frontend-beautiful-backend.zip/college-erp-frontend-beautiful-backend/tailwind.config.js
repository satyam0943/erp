export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          500: '#6366F1',
          600: '#4F46E5',
          700: '#4338CA',
        }
      },
      boxShadow: {
        soft: '0 18px 45px rgba(15,23,42,0.35)',
      },
    },
  },
  plugins: [],
}
