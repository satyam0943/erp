# College ERP Frontend (Beautiful UI + Backend Hooks)

This is a React + Vite + Tailwind frontend for a College ERP **already wired with generic backend API calls**.
You just need to adjust the endpoint URLs to match your backend.

## Tech stack

- React 18
- Vite
- TailwindCSS
- React Router
- Axios (with a central `client.js`)

## Backend integration

Set your API base URL in a `.env` file at project root:

```env
VITE_API_BASE_URL="http://localhost:4000/api"
```

By default, it uses `http://localhost:4000/api` if env is missing.

Endpoints used (you can change inside the page files):

- `POST /auth/login` — login
- `GET /dashboard-summary` — dashboard summary + upcoming tasks
- `GET /attendance?date=YYYY-MM-DD` — subject-wise attendance
- `GET /fees` — list of fee invoices
- `POST /fees/:id/pay` — pay an invoice
- `GET /fees/:id/receipt` — download receipt (PDF/blob)
- `GET /outpass` — list outpass requests
- `POST /outpass` — create new outpass request
- `GET /assignments` — list assignments
- `POST /assignments/:id/submit` — assignment file upload (multipart/form-data)
- `GET /profile` — student profile

You can rename these in `/src/pages/*.jsx` if your backend routes are different.

## Run

```bash
npm install
npm run dev
```

Open the URL that Vite prints (usually http://localhost:5173).

