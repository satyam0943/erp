import { useEffect, useState } from 'react'
import { StatusBadge } from '../components/Badge'
import client from '../api/client'

export default function Fees() {
  const [invoices, setInvoices] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    async function load() {
      setLoading(true)
      try {
        // Expected backend: GET /fees or /invoices
        const res = await client.get('/fees')
        setInvoices(res.data || [])
      } catch (err) {
        console.error(err)
        setInvoices([])
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  async function handlePay(inv) {
    try {
      // Expected backend: POST /fees/:id/pay
      await client.post(`/fees/${inv.id}/pay`)
      // reload list
      const res = await client.get('/fees')
      setInvoices(res.data || [])
    } catch (err) {
      console.error(err)
      alert('Payment API failed. Check backend route.')
    }
  }

  async function handleDownload(inv) {
    try {
      // Adjust to your receipt download endpoint
      const res = await client.get(`/fees/${inv.id}/receipt`, {
        responseType: 'blob',
      })
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url
      a.download = `receipt-${inv.id}.pdf`
      document.body.appendChild(a)
      a.click()
      a.remove()
      window.URL.revokeObjectURL(url)
    } catch (err) {
      console.error(err)
      alert('Download failed. Check backend route.')
    }
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-slate-400 mb-1">
            Finance
          </p>
          <h2 className="text-2xl font-semibold text-slate-50">Fees & Payments</h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            View your fee status, payment history and download receipts.
          </p>
        </div>
      </header>

      <div className="rounded-2xl border border-slate-800/80 bg-slate-900/70 p-4 space-y-4">
        {loading ? (
          <p className="text-sm text-slate-400 text-center py-6">Loading...</p>
        ) : invoices.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-6">
            No invoices found for this semester.
          </p>
        ) : (
          invoices.map((inv) => (
            <div
              key={inv.id}
              className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 border border-slate-800/80 rounded-2xl bg-slate-950/60 px-4 py-3"
            >
              <div>
                <p className="text-sm font-medium text-slate-100">
                  {inv.title || inv.description}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  Due by{' '}
                  <span className="text-slate-200">{inv.due || inv.dueDate}</span>
                </p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm font-semibold text-slate-50">
                    ₹ {(inv.amount ?? inv.total)?.toLocaleString('en-IN')}
                  </p>
                  <div className="mt-1">
                    <StatusBadge
                      status={inv.status === 'Paid' ? 'Paid' : 'Unpaid'}
                    />
                  </div>
                </div>
                {inv.status !== 'Paid' ? (
                  <button
                    onClick={() => handlePay(inv)}
                    className="rounded-xl bg-gradient-to-r from-primary-500 to-indigo-500 px-4 py-2 text-xs font-medium text-white shadow-soft hover:opacity-95 transition"
                  >
                    Pay now
                  </button>
                ) : (
                  <button
                    onClick={() => handleDownload(inv)}
                    className="rounded-xl border border-slate-700 px-3 py-2 text-xs text-slate-200 hover:bg-slate-800/80 transition"
                  >
                    Download receipt
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
