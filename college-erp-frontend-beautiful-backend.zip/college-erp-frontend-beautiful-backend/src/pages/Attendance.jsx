import { useEffect, useState } from 'react'
import { StatusBadge } from '../components/Badge'
import client from '../api/client'

export default function Attendance() {
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10))
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    async function load() {
      setLoading(true)
      try {
        // Expected backend: GET /attendance?date=YYYY-MM-DD
        // Should return array of { code, name, percent } or similar
        const res = await client.get('/attendance', { params: { date } })
        const data = res.data || []
        setRecords(
          data.map((r) => ({
            code: r.code || r.courseCode,
            name: r.name || r.courseName,
            percent: r.percent ?? r.percentage ?? 0,
          }))
        )
      } catch (err) {
        console.error(err)
        setRecords([])
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [date])

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-slate-400 mb-1">
            Academics
          </p>
          <h2 className="text-2xl font-semibold text-slate-50">Attendance</h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Check subject-wise attendance and identify low-risk courses quickly.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-300">
            As of
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="ml-2 rounded-xl border border-slate-700 bg-slate-900/80 px-2 py-1 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-primary-500"
            />
          </label>
        </div>
      </header>

      <div className="overflow-x-auto rounded-2xl border border-slate-800/80 bg-slate-900/70">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b border-slate-800/80 bg-slate-900/80">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.15em] text-slate-400">
                Code
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.15em] text-slate-400">
                Subject
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.15em] text-slate-400">
                Attendance
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.15em] text-slate-400">
                Status
              </th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td
                  colSpan={4}
                  className="px-4 py-6 text-center text-sm text-slate-400"
                >
                  Loading...
                </td>
              </tr>
            ) : records.length === 0 ? (
              <tr>
                <td
                  colSpan={4}
                  className="px-4 py-6 text-center text-sm text-slate-400"
                >
                  No attendance data.
                </td>
              </tr>
            ) : (
              records.map((r) => (
                <tr
                  key={r.code}
                  className="border-b border-slate-800/60 last:border-0 hover:bg-slate-900/70 transition"
                >
                  <td className="px-4 py-3 text-xs md:text-sm">{r.code}</td>
                  <td className="px-4 py-3 text-xs md:text-sm text-slate-100/90">
                    {r.name}
                  </td>
                  <td className="px-4 py-3 text-xs md:text-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-28 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            r.percent >= 75
                              ? 'bg-emerald-400'
                              : r.percent >= 60
                              ? 'bg-amber-400'
                              : 'bg-rose-400'
                          }`}
                          style={{ width: `${Math.min(r.percent, 100)}%` }}
                        />
                      </div>
                      <span>{r.percent}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs md:text-sm">
                    <StatusBadge
                      status={
                        r.percent >= 75 ? 'Safe' : r.percent >= 60 ? 'Warning' : 'Low'
                      }
                    />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
