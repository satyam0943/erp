import client from '../api/client'

export default function Login() {
  async function handleSubmit(e) {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const payload = {
      username: formData.get('username'),
      password: formData.get('password'),
    }
    try {
      // Adjust endpoint to your backend login route
      await client.post('/auth/login', payload)
      alert('Logged in! (Wire this to state / token storage)')
    } catch (err) {
      console.error(err)
      alert('Login failed. Check credentials / API.')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="w-full max-w-md rounded-3xl border border-slate-800/80 bg-slate-950/80 p-6 md:p-8 shadow-soft backdrop-blur-2xl">
        <div className="flex flex-col items-center mb-6">
          <div className="h-12 w-12 rounded-3xl bg-gradient-to-tr from-primary-500 to-indigo-400 flex items-center justify-center text-2xl shadow-soft mb-3">
            🎓
          </div>
          <h1 className="text-xl font-semibold text-slate-50">College ERP Login</h1>
          <p className="text-xs text-slate-400 mt-1">Use your college credentials to continue.</p>
        </div>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Email / PRN</label>
            <input
              name="username"
              className="w-full rounded-xl border border-slate-700 bg-slate-900/80 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="you@college.edu"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
            <input
              name="password"
              type="password"
              className="w-full rounded-xl border border-slate-700 bg-slate-900/80 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-2xl bg-gradient-to-r from-primary-500 via-indigo-500 to-sky-500 px-4 py-2.5 text-sm font-semibold text-white shadow-soft hover:opacity-95 transition"
          >
            Sign in
          </button>
        </form>
      </div>
    </div>
  )
}
