import { useEffect, useState } from 'react'
import { StatusBadge } from '../components/Badge'
import client from '../api/client'

export default function Outpass() {
  const [form, setForm] = useState({
    fromDate: '',
    toDate: '',
    reason: '',
    destination: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(false)

  async function loadRequests() {
    setLoading(true)
    try {
      // Expected backend: GET /outpass
      const res = await client.get('/outpass')
      setRequests(res.data || [])
    } catch (err) {
      console.error(err)
      setRequests([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadRequests()
  }, [])

  function handleChange(e) {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      // Expected backend: POST /outpass
      await client.post('/outpass', form)
      setForm({ fromDate: '', toDate: '', reason: '', destination: '' })
      await loadRequests()
    } catch (err) {
      console.error(err)
      alert('Outpass submit failed. Check backend route / payload.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-slate-400 mb-1">
            Hostel
          </p>
          <h2 className="text-2xl font-semibold text-slate-50">Outpass</h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Apply for outpass and track the approval status from warden and faculty.
          </p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-1 rounded-2xl border border-slate-800/80 bg-slate-900/70 p-4 space-y-3"
        >
          <h3 className="text-sm font-medium text-slate-100 mb-1">
            Apply for new outpass
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-300 mb-1">From date</label>
              <input
                type="date"
                name="fromDate"
                value={form.fromDate}
                onChange={handleChange}
                className="w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-300 mb-1">To date</label>
              <input
                type="date"
                name="toDate"
                value={form.toDate}
                onChange={handleChange}
                className="w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">Destination</label>
            <input
              name="destination"
              value={form.destination}
              onChange={handleChange}
              placeholder="City / Place you are visiting"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-xs text-slate-100 placeholder-slate-500 outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">Reason</label>
            <textarea
              name="reason"
              rows={3}
              value={form.reason}
              onChange={handleChange}
              placeholder="Explain why you need outpass"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-xs text-slate-100 placeholder-slate-500 outline-none focus:ring-2 focus:ring-primary-500 resize-none"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-2xl bg-gradient-to-r from-primary-500 via-indigo-500 to-sky-500 px-4 py-2.5 text-xs font-semibold text-white shadow-soft hover:opacity-95 transition disabled:opacity-60"
          >
            {submitting ? 'Submitting…' : 'Submit request'}
          </button>
          <p className="text-[11px] text-slate-500 mt-1">
            Note: Outpass will be valid only after warden & faculty approval.
          </p>
        </form>

        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-slate-100">
              Recent outpass requests
            </h3>
            <div className="flex gap-2 text-[11px] text-slate-400">
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-400" /> Approved
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-amber-400" /> Pending
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-rose-400" /> Rejected
              </span>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800/80 bg-slate-900/70">
            <table className="min-w-full text-xs md:text-sm">
              <thead>
                <tr className="border-b border-slate-800/80 bg-slate-900/80">
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-400">
                    Applied on
                  </th>
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-400">
                    From
                  </th>
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-400">
                    To
                  </th>
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-400">
                    Reason
                  </th>
                  <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-400">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan={5}
                      className="px-4 py-6 text-center text-sm text-slate-400"
                    >
                      Loading...
                    </td>
                  </tr>
                ) : requests.length === 0 ? (
                  <tr>
                    <td
                      colSpan={5}
                      className="px-4 py-6 text-center text-sm text-slate-400"
                    >
                      No requests yet.
                    </td>
                  </tr>
                ) : (
                  requests.map((r) => (
                    <tr
                      key={r.id}
                      className="border-b border-slate-800/60 last:border-0 hover:bg-slate-900/70 transition"
                    >
                      <td className="px-4 py-3">
                        {r.appliedOn || r.applied_on || r.createdAt}
                      </td>
                      <td className="px-4 py-3">{r.fromDate || r.from_date}</td>
                      <td className="px-4 py-3">{r.toDate || r.to_date}</td>
                      <td className="px-4 py-3 max-w-xs truncate" title={r.reason}>
                        {r.reason}
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={r.status} />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
