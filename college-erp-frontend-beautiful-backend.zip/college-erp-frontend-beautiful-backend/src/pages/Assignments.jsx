import { useEffect, useState } from 'react'
import { StatusBadge } from '../components/Badge'
import client from '../api/client'

export default function Assignments() {
  const [items, setItems] = useState([])
  const [uploadingId, setUploadingId] = useState(null)

  async function loadAssignments() {
    try {
      // Expected backend: GET /assignments
      const res = await client.get('/assignments')
      setItems(res.data || [])
    } catch (err) {
      console.error(err)
      setItems([])
    }
  }

  useEffect(() => {
    loadAssignments()
  }, [])

  async function handleUpload(a, file) {
    try {
      setUploadingId(a.id)
      const form = new FormData()
      form.append('file', file)
      // Expected backend: POST /assignments/:id/submit (multipart/form-data)
      await client.post(`/assignments/${a.id}/submit`, form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      await loadAssignments()
    } catch (err) {
      console.error(err)
      alert('Upload failed. Check backend route / form-data handling.')
    } finally {
      setUploadingId(null)
    }
  }

  function onFileChange(e, a) {
    const file = e.target.files?.[0]
    if (!file) return
    handleUpload(a, file)
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-slate-400 mb-1">
            Academics
          </p>
          <h2 className="text-2xl font-semibold text-slate-50">Assignments</h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            View pending assignments, due dates and submission status.
          </p>
        </div>
      </header>

      <div className="rounded-2xl border border-slate-800/80 bg-slate-900/70 p-4 space-y-3">
        {items.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-6">
            No assignments found.
          </p>
        ) : (
          items.map((a) => (
            <div
              key={a.id}
              className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 border border-slate-800/80 rounded-2xl bg-slate-950/60 px-4 py-3"
            >
              <div>
                <p className="text-sm font-medium text-slate-100">{a.title}</p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {(a.course || a.courseCode) && (
                    <>
                      {a.course || a.courseCode} •{' '}
                    </>
                  )}
                  Due <span className="text-slate-200">{a.due || a.dueDate}</span>
                </p>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge status={a.status || (a.submitted ? 'Submitted' : 'Pending')} />
                {!a.submitted ? (
                  <label className="rounded-xl border border-slate-700 px-3 py-2 text-xs text-slate-200 hover:bg-slate-800/80 transition cursor-pointer">
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => onFileChange(e, a)}
                    />
                    {uploadingId === a.id ? 'Uploading…' : 'Upload & submit'}
                  </label>
                ) : (
                  <button className="rounded-xl border border-slate-700 px-3 py-2 text-xs text-slate-200 hover:bg-slate-800/80 transition">
                    View submission
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
