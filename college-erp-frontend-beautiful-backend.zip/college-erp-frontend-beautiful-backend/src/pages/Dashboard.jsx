import { useEffect, useState } from 'react'
import StatCard from '../components/StatCard'
import { SimpleTable } from '../components/Table'
import { StatusBadge } from '../components/Badge'
import client from '../api/client'

export default function Dashboard() {
  const [summary, setSummary] = useState({
    overallAttendance: null,
    feesDue: null,
    activeOutpasses: null,
    pendingTasks: null,
  })
  const [upcoming, setUpcoming] = useState([])

  useEffect(() => {
    async function load() {
      try {
        // Adjust this endpoint to your backend dashboard summary
        const res = await client.get('/dashboard-summary')
        setSummary(res.data.summary || {})
        setUpcoming(res.data.upcoming || [])
      } catch (err) {
        console.error(err)
        // fallback demo data
        setSummary({
          overallAttendance: '87%',
          feesDue: '₹ 12,000',
          activeOutpasses: '1',
          pendingTasks: '3',
        })
        setUpcoming([
          {
            course: 'DBMS - Assignment 3',
            due: '03 Dec 2025',
            type: 'Assignment',
            status: 'Pending',
          },
          {
            course: 'OS Lab Viva',
            due: '05 Dec 2025',
            type: 'Exam',
            status: 'Pending',
          },
        ])
      }
    }
    load()
  }, [])

  const upcomingRows = upcoming.map((u) => ({
    course: u.course,
    due: u.due,
    type: u.type,
    status: <StatusBadge status={u.status} />,
  }))

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-slate-400 mb-1">
            Overview
          </p>
          <h2 className="text-2xl md:text-3xl font-semibold text-slate-50">
            Dashboard
          </h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1 max-w-xl">
            Track your attendance, fees, outpass requests and academic progress in one
            place.
          </p>
        </div>
        <div className="flex gap-2 text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-900/80 px-3 py-1 border border-slate-700/80">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Synced with college ERP
          </span>
        </div>
      </section>

      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Overall Attendance"
          value={summary.overallAttendance ?? '...'}
          chip="This semester"
          accent="Safe zone"
        />
        <StatCard
          label="Fees Due"
          value={summary.feesDue ?? '...'}
          chip="Next due date"
        />
        <StatCard
          label="Active Outpasses"
          value={summary.activeOutpasses ?? '...'}
          chip="Pending / approved"
        />
        <StatCard
          label="Pending Tasks"
          value={summary.pendingTasks ?? '...'}
          chip="Assignments & fees"
        />
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-slate-100">Upcoming deadlines</h3>
            <span className="text-[11px] text-slate-400">Next 7–14 days</span>
          </div>
          <SimpleTable
            columns={[
              { key: 'course', label: 'Course / Task' },
              { key: 'due', label: 'Due' },
              { key: 'type', label: 'Type' },
              { key: 'status', label: 'Status' },
            ]}
            rows={upcomingRows}
            emptyText="No upcoming tasks."
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-slate-100">Quick notes</h3>
          </div>
          <div className="rounded-2xl border border-slate-800/80 bg-slate-900/70 p-4 text-xs md:text-sm text-slate-300 space-y-2">
            <p>• Internal exams schedule will be published on the ERP noticeboard.</p>
            <p>• Hostel outing is only allowed with an approved outpass.</p>
            <p>• Keep your attendance above the minimum requirement to avoid issues.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
