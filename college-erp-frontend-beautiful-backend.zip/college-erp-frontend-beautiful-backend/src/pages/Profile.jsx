import { useEffect, useState } from 'react'
import client from '../api/client'

export default function Profile() {
  const [profile, setProfile] = useState(null)

  useEffect(() => {
    async function load() {
      try {
        // Expected backend: GET /profile or /me
        const res = await client.get('/profile')
        setProfile(res.data)
      } catch (err) {
        console.error(err)
        setProfile({
          name: 'Student',
          roll: 'ROLL123',
          program: 'B.Tech Computer Science',
          semester: 'V',
          email: 'student@college.edu',
          phone: '+91 98765 43210',
        })
      }
    }
    load()
  }, [])

  const data = profile || {}

  return (
    <div className="space-y-5">
      <header>
        <p className="text-xs uppercase tracking-[0.18em] text-slate-400 mb-1">
          Account
        </p>
        <h2 className="text-2xl font-semibold text-slate-50">Profile</h2>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          View and update your basic student information.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="rounded-2xl border border-slate-800/80 bg-slate-900/70 p-5 flex flex-col items-center gap-3">
          <div className="h-16 w-16 rounded-full bg-gradient-to-tr from-primary-500 to-indigo-400 flex items-center justify-center text-2xl font-semibold shadow-soft">
            {(data.name || 'ST')
              .split(' ')
              .map((s) => s[0])
              .join('')
              .slice(0, 2)
              .toUpperCase()}
          </div>
          <div className="text-center">
            <p className="text-sm font-semibold text-slate-50">{data.name}</p>
            <p className="text-xs text-slate-400">
              {data.program || 'Programme'} • {data.semester || 'Semester'}
            </p>
          </div>
          <button className="mt-2 rounded-xl border border-slate-700 px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800/80 transition">
            Change avatar
          </button>
        </div>

        <div className="lg:col-span-2 rounded-2xl border border-slate-800/80 bg-slate-900/70 p-5 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs md:text-sm">
            <ProfileField label="Full name" value={data.name} />
            <ProfileField label="PRN / Roll No." value={data.roll} />
            <ProfileField label="Program" value={data.program} />
            <ProfileField label="Semester" value={data.semester} />
            <ProfileField label="Email" value={data.email} />
            <ProfileField label="Phone" value={data.phone} />
          </div>
          <button className="rounded-xl bg-gradient-to-r from-primary-500 to-indigo-500 px-4 py-2 text-xs font-medium text-white shadow-soft hover:opacity-95 transition">
            Edit details
          </button>
        </div>
      </div>
    </div>
  )
}

function ProfileField({ label, value }) {
  return (
    <div>
      <p className="text-[11px] uppercase tracking-[0.15em] text-slate-500 mb-1">
        {label}
      </p>
      <div className="rounded-xl border border-slate-800/80 bg-slate-950/60 px-3 py-2 text-slate-100">
        {value || '-'}
      </div>
    </div>
  )
}
