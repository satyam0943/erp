export function StatusBadge({ status }) {
  const map = {
    Approved: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/40',
    Pending: 'bg-amber-500/10 text-amber-300 border-amber-500/40',
    Rejected: 'bg-rose-500/10 text-rose-300 border-rose-500/40',
    Paid: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/40',
    Unpaid: 'bg-amber-500/10 text-amber-300 border-amber-500/40',
    Safe: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/40',
    Warning: 'bg-amber-500/10 text-amber-300 border-amber-500/40',
    Low: 'bg-rose-500/10 text-rose-300 border-rose-500/40',
    Submitted: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/40',
  }
  const cls = map[status] || 'bg-slate-700/60 text-slate-200 border-slate-500/40'
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${cls}`}
    >
      {status}
    </span>
  )
}
