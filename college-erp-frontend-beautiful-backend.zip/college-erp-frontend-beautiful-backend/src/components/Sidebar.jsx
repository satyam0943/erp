import { NavLink } from 'react-router-dom'
import { useState } from 'react'

const navItems = [
  { to: '/', label: 'Dashboard', icon: '📊' },
  { to: '/attendance', label: 'Attendance', icon: '🗓️' },
  { to: '/fees', label: 'Fees', icon: '💰' },
  { to: '/outpass', label: 'Outpass', icon: '🚪' },
  { to: '/assignments', label: 'Assignments', icon: '📚' },
  { to: '/profile', label: 'Profile', icon: '👤' },
]

export default function Sidebar() {
  const [open, setOpen] = useState(false)

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="md:hidden fixed z-40 top-4 left-4 inline-flex h-10 w-10 items-center justify-center rounded-full bg-slate-900/80 border border-slate-700/60 shadow-soft backdrop-blur-xl"
      >
        <span className="text-xl">{open ? '✕' : '☰'}</span>
      </button>

      <aside
        className={`fixed z-30 inset-y-0 left-0 w-64 bg-slate-950/80 border-r border-slate-800/80 backdrop-blur-2xl shadow-soft transition-transform duration-300 md:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="h-16 flex items-center px-5 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-2xl bg-gradient-to-tr from-primary-500 to-indigo-400 flex items-center justify-center text-lg shadow-soft">
              🎓
            </div>
            <div>
              <div className="font-semibold tracking-tight">Quantum College</div>
              <div className="text-xs text-slate-400">Student ERP</div>
            </div>
          </div>
        </div>

        <nav className="px-3 py-4 space-y-1 overflow-y-auto h-[calc(100vh-4rem)]">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                'flex items-center gap-3 px-3 py-2.5 text-sm rounded-xl transition ' +
                (isActive
                  ? 'bg-primary-600/90 text-white shadow-soft shadow-primary-600/40'
                  : 'text-slate-300 hover:bg-slate-800/70 hover:text-white')
              }
              onClick={() => setOpen(false)}
            >
              <span className="text-lg">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>
    </>
  )
}
