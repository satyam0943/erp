export default function StatCard({ label, value, chip, accent }) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-soft">
      <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-gradient-to-br from-primary-500/20 via-indigo-500/10 to-transparent blur-2xl" />
      <div className="p-4 md:p-5 relative">
        <p className="text-xs uppercase tracking-[0.16em] text-slate-400 mb-1">
          {label}
        </p>
        <div className="flex items-end justify-between gap-2">
          <div>
            <p className="text-2xl md:text-3xl font-semibold text-slate-50">{value}</p>
            {chip && (
              <p className="mt-1 inline-flex items-center rounded-full border border-slate-700/80 bg-slate-900/80 px-2 py-0.5 text-[11px] text-slate-300">
                {chip}
              </p>
            )}
          </div>
          {accent && (
            <span className="text-xs font-medium rounded-full px-2 py-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
              {accent}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
