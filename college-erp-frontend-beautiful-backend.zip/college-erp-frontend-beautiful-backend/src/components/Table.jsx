export function SimpleTable({ columns, rows, emptyText }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-800/80 bg-slate-900/70">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-slate-800/80 bg-slate-900/80">
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.15em] text-slate-400"
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length}
                className="px-4 py-6 text-center text-sm text-slate-400"
              >
                {emptyText || 'No data to show.'}
              </td>
            </tr>
          ) : (
            rows.map((row, idx) => (
              <tr
                key={idx}
                className="border-b border-slate-800/60 last:border-0 hover:bg-slate-900/70 transition"
              >
                {columns.map((col) => (
                  <td key={col.key} className="px-4 py-3 text-slate-100/90 text-xs md:text-sm">
                    {row[col.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}
