export default function Topbar() {
  return (
    <header className="fixed left-0 md:left-64 right-0 top-0 z-20">
      <div className="backdrop-blur-xl bg-slate-900/70 border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-4 md:px-6 h-16">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-slate-400">
              Student Portal
            </p>
            <h1 className="text-sm md:text-base font-semibold text-slate-50">
              Welcome back, <span className="text-primary-400">Student</span>
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-3 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/80">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs text-slate-300">Online</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-medium text-slate-200">Student</div>
                <div className="text-[11px] text-slate-400">B.Tech • CSE</div>
              </div>
              <div className="h-9 w-9 rounded-full bg-gradient-to-tr from-primary-500 to-indigo-400 flex items-center justify-center text-sm font-semibold shadow-soft">
                ST
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
